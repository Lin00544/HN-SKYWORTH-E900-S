# /system/bin/sh

# Skyworth E900-S netchange.sh
# eth0: iTV cable (PPPOE)
# wlan0: internet wifi

# mount -o rw,remount /system
# cp /mnt/usb/sda4/netchange.sh /system/bin/netchange.sh
# chmod 0755 /system/bin/netchange.sh
# echo "sh /system/bin/netchange.sh &" >> /system/bin/NetArgsCfg.sh

# disable upgrade
# pm block com.ztestb.upgrade

# just enable wifi but don't connect
# svc wifi enable

# wait for itv link up
# while [ "$(getprop net.zte.eth.netstate)" != "CONNECTED" ]
# do
# sleep 1
# done

# 0:web 1:itv

itv=1

while [ 1 ]
do 
	# check whether itv is current window 
	itv_app=$( dumpsys window windows | grep -E 'mCurrentFocus|mFocusedApp' | grep -E com.skyworth.iptv | busybox wc -l )

	if [ $itv_app != 0 ] ; then
		itv=1 
		svc wifi disable
		sleep 3 
		# am start com.skyworth.iptv
		echo "=switched to itv..."
	elif [ $itv_app = 0 ] ; then
		itv=0 
		svc wifi enable 
		echo "=switched to wifi..."
	fi

	sleep 1

done